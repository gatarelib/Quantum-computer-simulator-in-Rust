pub static KERNEL: &'static str = include_str!("cl/kernel.cl");
