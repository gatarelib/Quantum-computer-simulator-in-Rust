# Algorithms

The following chapter details some implementations of non trivial quantum algorithms. They are based on the source code from [libquantum](http://www.libquantum.de/) along with the lecture notes from [the University of Waterloo](https://cs.uwaterloo.ca/~watrous/LectureNotes.html).

Note that some implementations may not yet be complete.
