# User Guide

This chapter covers the usage of the QCGPU library. It will also contain some information about the mathematics that each of the functions represents.

All aspects of the library are covered by this chapter, whereas complete examples (in the form of algorithm implementations) are available in the [Algorithms Chapter](../algorithms/algorithms.html)
